This is available under the GNU General Public License, version 3 (or, at your
option, any later version.)
