read DirList

sed '/^$/d;s/ /\//g' $DirList | xargs mkdir -p 
